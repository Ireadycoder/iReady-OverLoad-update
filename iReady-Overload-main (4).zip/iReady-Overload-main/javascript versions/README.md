# Javascript Versions

I do not recommend using these, simply there if you want to know how it works. I recommend using the chrome extension or bookmarklet instead.