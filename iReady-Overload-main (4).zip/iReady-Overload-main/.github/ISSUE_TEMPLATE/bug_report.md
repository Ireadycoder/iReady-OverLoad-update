---
name: Bug report
about: Create a report to help us improve
title: '[BUG]'
labels: issue
assignees: ''

---

**Describe the bug**

**To Reproduce**

**Expected behavior**

**Screenshot(s)/Video**

**Additional info**
