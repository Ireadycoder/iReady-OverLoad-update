// creates UI
var UI = document.createElement("div");
UI.innerHTML = `
	<div id="SLbQf" style="width:250px; left: 1px; top: 1px; background-color: #282828; color: white; outline: black solid 1px; position:absolute; z-index: 99999;">
		<h1 style="font-size: 33px;">iReady&nbsp;Overload</h1>

		<br>

		<i>Press ctrl + z to hide or show this panel at any time.</i>

		<br>
		<br>

		<h2 style="font-size: 26px; font-style: normal !important; color: white !important;">Lesson&nbsp;Skipper</h2>

		<button onclick="skipLesson()">Skip&nbsp;current lesson</button>

		<br>
		<br>

		<h2 style="font-size: 26px; font-style: normal !important; color: white !important;">Minutes&nbsp;Hack</h2>

		<button onclick="farmMinutes(this)">Farm&nbsp;minutes</button>

    <br>
		<br>

		<h2 style="font-size: 26px; font-style: normal !important; color: white !important;">Diagnostic&nbsp;Hack</h2>

		<button onclick="diagnosticHack(this)">Enable</button>
				<br>
		<br>
		<hr>
		tool by <a href="https://github.com/Ireadycoder">ireadycoder (github)</a>
		<br>
		<br>
	</div>`

// injects functions into iready site
var functionsScript = document.createElement("script");
functionsScript.innerHTML = `var minuteFarming = false; var skippingLesson = false; var skippingLesson1 = false; var skippingLesson2 = false; ${skipLesson.toString()} \n ${farmMinutes.toString()} \n ${diagnosticHack.toString()} \n ${getCookie.toString()} document.addEventListener('keydown', function(e){ if (event.ctrlKey && event.key == "z"){ if(SLbQf.style.display == "block"){ SLbQf.style.display = "none"; } else { SLbQf.style.display = "block"; } } });\n`
document.body.appendChild(functionsScript);
// shamelessly stolen from https://www.w3schools.com/howto/howto_js_draggable.asp
//Make the DIV element draggagle:
dragElement(UI.firstElementChild);
document.body.appendChild(UI);

function dragElement(elmnt) {
	var pos1 = 0,
		pos2 = 0,
		pos3 = 0,
		pos4 = 0;
	if (document.getElementById(elmnt.id + "header")) {
		/* if present, the header is where you move the DIV from:*/
		document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
	} else {
		/* otherwise, move the DIV from anywhere inside the DIV:*/
		elmnt.onmousedown = dragMouseDown;
	}

	function dragMouseDown(e) {
		e = e || window.event;
		e.preventDefault();
		// get the mouse cursor position at startup:
		pos3 = e.clientX;
		pos4 = e.clientY;
		document.onmouseup = closeDragElement;
		// call a function whenever the cursor moves:
		document.onmousemove = elementDrag;
	}

	function elementDrag(e) {
		e = e || window.event;
		e.preventDefault();
		// calculate the new cursor position:
		pos1 = pos3 - e.clientX;
		pos2 = pos4 - e.clientY;
		pos3 = e.clientX;
		pos4 = e.clientY;
		// set the element's new position:
		elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
		elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
	}

	function closeDragElement() {
		/* stop moving when mouse button is released:*/
		document.onmouseup = null;
		document.onmousemove = null;
	}
}

function skipLesson() {
    function one() {
        // main one used by i-ready
		var alerted = false;
        alert("In order to skip this lesson, correcly answer one question.")
		skippingLesson1 = true;
        XMLHttpRequest.prototype.nativeSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.send = function(body){
			if (body) {
				if (body.search("highestReachedStepId") > -1 && skippingLesson1) {
					var lol = body.replaceAll('"complete\\\":false','"complete\\\":true');
					var lol2 = lol.replaceAll('"finished\\\":false','"finished\\\":true');
					this.nativeSend(lol2);
					if (!alerted) {
						alert("To complete skipping:\nRefresh the page\nOpen the lesson\nClose it\nContinue closing/opening until it says you've passed (you will also see progress going up on the bottom)")
						alerted = true;
					}
				}
        	}
		}
    }
    function two() {
		// alternative not as used one
		var lessonId = html5Iframe.src.split("/")[html5Iframe.src.split("/").length - 1];
		var csid = html5Iframe.src.split("?csid=")[1].split("&type")[0];
		var lessonType = lessonId.split("_")[lessonId.split("_").length - 1];
		var subject = csid.includes("math") ? "math" : "reading";
		
		// empty global variables for later use
		var slidesCompletedArr = [];
		var scoreArr = [];
		var slideCount;
		
		// gets lesson strucure
		html5Iframe.contentWindow.fetch(`https://cdn.i-ready.com/instruction/phoenix-content/${subject}/${lessonId}/lessonStructure.json`, {
				"headers": {
					"accept": "application/json, text/plain, */*",
					"accept-language": "en-US,en;q=0.9",
					"sec-fetch-dest": "empty",
					"sec-fetch-mode": "cors",
					"sec-fetch-site": "same-origin",
					"sec-gpc": "1"
				},
				"referrer": "https://login.i-ready.com/student/dashboard/home",
				"referrerPolicy": "strict-origin-when-cross-origin",
				"body": null,
				"method": "GET",
				"mode": "cors",
				"credentials": "include"
			}).then(response => response.json())
			.then(function(data) {
				console.log();
				slideCount = data.lessonStructureObj.slideData.length;
		
				slidesCompletedArr = [];
				scoreArr = [];
		
				// creates score and completion arrays with the length neccessary
				for (var i = 0; i < slideCount; i++) {
					slidesCompletedArr.push(true);
					scoreArr.push(1);
				}
		
				// sets cookies
				document.cookie = `lessonId=${lessonId};`
				document.cookie = `lessonType=${lessonType};`
				document.cookie = `subject=${subject};`
				document.cookie = `csid=${csid};`
				document.cookie = `slidesCompletedArr=${slidesCompletedArr};`
				document.cookie = `scoreArr=${scoreArr};`
				document.cookie = `slideCount=${slideCount};`
			});
			alert("To skip this lesson, close the lesson and click the skip button again.")
			skippingLesson2 = true;
			skippingLesson = true;
    }

	if (!window["html5Iframe"] && !window["closereading_lesson"] && !skippingLesson) {
			alert("You do not have a lesson currently open. You must open a lesson to skip it.");
		}
		else if (window["html5Iframe"] && !skippingLesson){
			var lessonId = html5Iframe.src.split("/")[html5Iframe.src.split("/").length - 1];
			var csid = html5Iframe.src.split("?csid=")[1].split("&type")[0];
			var subject = csid.includes("math") ? "math" : "reading";
            html5Iframe.contentWindow.fetch(`https://cdn.i-ready.com/instruction/phoenix-content/${subject}/${lessonId}/lessonStructure.json`, {
                "headers": {
                    "accept": "application/json, text/plain, */*",
                    "accept-language": "en-US,en;q=0.9",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin",
                    "sec-gpc": "1"
                },
                "referrer": "https://login.i-ready.com/student/dashboard/home",
                "referrerPolicy": "strict-origin-when-cross-origin",
                "body": null,
                "method": "GET",
                "mode": "cors",
                "credentials": "include"
            }).then(function(response) {
                if (response.status == 404) {
                    one()
                    console.log("Using method 1")
                } else {
                    two()
                    console.log("Using method 2")
                }
		
            })
		} else if (!window["html5Iframe"] && skippingLesson2) {
			var lessonId = getCookie("lessonId");
			var lessonType = getCookie("lessonType");
			var csid = getCookie("csid");
			var slidesCompletedArr = getCookie("slidesCompletedArr");
			var scoreArr = getCookie("scoreArr");
			var slideCount = parseInt(getCookie("slideCount"), 10);

			fetch(`https://login.i-ready.com/student/v2/web/lesson_component/${csid}/markprogress/${csid}`, {
				"headers": {
					"accept": "*/*",
					"accept-language": "en-US,en;q=0.9",
					"content-type": "application/json;charset=UTF-8",
					"sec-fetch-dest": "empty",
					"sec-fetch-mode": "cors",
					"sec-fetch-site": "same-origin",
					"sec-gpc": "1"
				},
				"referrer": "https://login.i-ready.com/student/dashboard/home",
				"referrerPolicy": "strict-origin-when-cross-origin",
				"body": `{\"value\":\"{\\\"finalStageArr\\\":[],\\\"curSlideInt\\\":${slideCount - 1},\\\"slideCompletedArr\\\":[${slidesCompletedArr}],\\\"allScoreDataArr\\\":[${scoreArr}],\\\"stateStoreDataObj\\\":{}}\",\"bucket\":\"short_term_unsecured\",\"datatype\":\"json\"}`,
				"method": "POST",
				"mode": "cors",
				"credentials": "include"
			});
			alert("Open the lesson and you should see it was skipped. You may need to answer the final question (anything you put down will be marked as correct)")
			skippingLesson2 = false;
			skippingLesson = false;
		}
	}

	function farmMinutes(buttonId) {
		// checks if currently farming minutes
		if (minuteFarming) {
			csid = getCookie("csid");

			// sends fetch request to stop timer and update time
			fetch(`https://login.i-ready.com/student/v1/web/lesson_component/${csid}?action=pause`, {
				"headers": {
					"accept": "application/json, text/plain, */*",
					"accept-language": "en-US,en;q=0.9",
					"sec-fetch-dest": "empty",
					"sec-fetch-mode": "cors",
					"sec-fetch-site": "same-origin"
				},
				"referrer": "https://login.i-ready.com/student/dashboard/home",
				"referrerPolicy": "strict-origin-when-cross-origin",
				"body": null,
				"method": "GET",
				"mode": "cors",
				"credentials": "include"
			});

			// resets some variables
			document.cookie = `csid=; expires=Thu, 18 Dec 1970 12:00:00 UTC"`;
			buttonId.innerText = "Farm minutes";
			minuteFarming = false;

			alert("The minutes should now be in your account.");
		}
		// checks if lesson/quiz is open
		if (!!window["html5Iframe"]) {
			// gets lesson data
			var csid = html5Iframe.src.split("?csid=")[1].split("&type")[0];
			var minutes = 45; // change the 45 to the amount of time you want. This is only neccessary for the alternate hack.

			// sets cookies in case something breaks
			document.cookie = `csid=${csid}; expires=Thu, 18 Dec 2999 12:00:00 UTC"`;
			document.cookie = `minutes=${minutes}; expires=Thu, 18 Dec 2999 12:00:00 UTC"`;

			alert("Neccessary data to farm minutes have now been collected. To begin farming minutes, go to the iReady menu by closing this lesson/quiz. Then, press this button again.");
		} else if (!getCookie("csid")) {
			// lesson isn't open and cookie isnt set
			alert("You do not have a lesson currently open. You must open a lesson to begin the proccess.")
		} else {
			// lesson isn't open and cookie is set
			csid = getCookie("csid");

			// sends fetch request to start timer
			fetch(`https://login.i-ready.com/student/v1/web/lesson_component/${csid}?action=resume`, {
				"headers": {
					"accept": "application/json, text/plain, */*",
					"accept-language": "en-US,en;q=0.9",
					"sec-fetch-dest": "empty",
					"sec-fetch-mode": "cors",
					"sec-fetch-site": "same-origin"
				},
				"referrer": "https://login.i-ready.com/student/dashboard/home",
				"referrerPolicy": "strict-origin-when-cross-origin",
				"body": null,
				"method": "GET",
				"mode": "cors",
				"credentials": "include"
			});

			// sets variable to know minutes are being farmed
			minuteFarming = true;
			buttonId.innerText = "Stop farming minutes";

			alert("The minute farming process has now begun. Do not close this page. Do not turn off your computer. After you press \"ok,\" every minute that passes will be added to your account. When you want to stop the timer and add the farmed minutes to your account, press the button labeled \"Stop farming minutes\". Press \"ok\" to begin.");
		}
	}

	function diagnosticHack(buttonId) {
		//checks if diagnostic hack is enabled
		if (!!XMLHttpRequest.prototype.realSend) {
			// disables hack
			XMLHttpRequest.prototype.send = XMLHttpRequest.prototype.realSend;
			XMLHttpRequest.prototype.realSend = undefined;
			alert("Hack was disabled.")
			buttonId.innerText = "Enable hack";
		} else {
			// checks if diagnostic is open
			if (typeof diagnosticIFrame == "undefined") {
				alert("Diagnostic not detected. Open the diagnostic first to use the hack.")
			} else if (!XMLHttpRequest.prototype.realSend) {
				var duration = 1000;

				// hijacks XMLHttpRequest.send() to modify requests
				XMLHttpRequest.prototype.realSend = XMLHttpRequest.prototype.send;
				XMLHttpRequest.prototype.send = function(body) {
					// modifies inputted request
					newBody = JSON.parse(body);
					if (newBody.correct == false) newBody.correct = true;
					if (newBody.durationSeconds != undefined) newBody.durationSeconds = duration;

					// sends actual request
					this.realSend(JSON.stringify(newBody));
				}
				alert("Hack was enabled. All answers inputted in diagnostic will be correct. Please do not answer questions too fast or your test will be marked as rushed.");
				buttonId.innerText = "Disable hack";
			}
		}
	}

	function getCookie(cname) {
		var name = cname + "=";
		var decodedCookie = decodeURIComponent(document.cookie);
		var ca = decodedCookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') {
				c = c.substring(1);
			}
			if (c.indexOf(name) == 0) {
				return c.substring(name.length, c.length);
			}
		}
		return "";
	}	